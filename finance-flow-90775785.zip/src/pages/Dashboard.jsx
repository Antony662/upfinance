
import React, { useState, useEffect } from "react";
import { Transaction } from "@/api/entities";
import { Goal } from "@/api/entities";
import { User } from "@/api/entities";
import { BankAccount } from "@/api/entities";
import { CreditCard } from "@/api/entities";
import { Debt } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, DollarSign, TrendingUp, Target, Receipt } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { safeNumber, formatCurrency, sanitizeChartData } from "../components/utils/safeNumbers";

import StatsCard from "../components/dashboard/StatsCard";
import RadialProgressCard from "../components/dashboard/RadialProgressCard";
import TransactionForm from "../components/forms/TransactionForm";
import QuickActions from "../components/dashboard/QuickActions";
import AccountsOverview from "../components/dashboard/AccountsOverview";

// A simple mock for triggerWebhook. In a real application, this would likely be an API call
// to your backend or a third-party webhook service.
const triggerWebhook = async (data) => {
  console.log("Attempting to trigger webhook:", data);
  // Simulate an asynchronous API call
  return new Promise(resolve => setTimeout(() => {
    console.log("Webhook triggered successfully for event:", data.event, "with payload:", data.payload);
    resolve({ success: true, message: "Webhook processed" });
  }, 500));
};

export default function Dashboard() {
  const [transactions, setTransactions] = useState([]);
  const [goals, setGoals] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [creditCards, setCreditCards] = useState([]);
  const [debts, setDebts] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showTransactionForm, setShowTransactionForm] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [userResponse, transactionsResponse, goalsResponse, accountsResponse, cardsResponse, debtsResponse] = await Promise.all([
        User.me(),
        Transaction.filter({ workspace: "personal" }, "-created_date", 10),
        Goal.filter({ workspace: "personal" }, "-created_date", 5),
        BankAccount.filter({ workspace: "personal" }),
        CreditCard.filter({ workspace: "personal" }),
        Debt.filter({ workspace: "personal" })
      ]);

      setUser(userResponse);
      setTransactions(Array.isArray(transactionsResponse) ? transactionsResponse : []);
      setGoals(Array.isArray(goalsResponse) ? goalsResponse : []);
      setBankAccounts(Array.isArray(accountsResponse) ? accountsResponse : []);
      setCreditCards(Array.isArray(cardsResponse) ? cardsResponse : []);
      setDebts(Array.isArray(debtsResponse) ? debtsResponse : []);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      setTransactions([]);
      setGoals([]);
      setBankAccounts([]);
      setCreditCards([]);
      setDebts([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTransaction = async (transactionData) => {
    try {
      const result = await Transaction.create(transactionData);
      
      // Disparar webhook após criar a transação
      try {
        await triggerWebhook({
          event: 'transaction.created',
          payload: result
        });
      } catch (webhookError) {
        console.error("Erro ao disparar webhook:", webhookError);
      }
      
      setShowTransactionForm(false);
      loadData();
      return result;
    } catch (error) {
      console.error("Erro ao adicionar transação:", error);
    }
  };

  const handleQuickAction = (action) => {
    switch (action) {
      case "new-transaction":
        setShowTransactionForm(true);
        break;
      case "new-goal":
        window.location.href = "/Goals";
        break;
      case "new-card":
        window.location.href = "/Accounts";
        break;
      case "new-account":
        window.location.href = "/Accounts";
        break;
      case "new-debt":
        window.location.href = "/Debts";
        break;
      case "new-event":
        window.location.href = "/Calendar";
        break;
      default:
        console.log("Ação não implementada:", action);
    }
  };

  const getMonthlyStats = () => {
    if (!Array.isArray(transactions)) return { income: 0, expenses: 0, balance: 0 };

    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const monthlyTransactions = transactions.filter(t => {
      if (!t || !t.date) return false;
      try {
        const date = new Date(t.date);
        return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
      } catch {
        return false;
      }
    });

    const income = monthlyTransactions
      .filter(t => t && t.type === "income")
      .reduce((sum, t) => sum + safeNumber(t.amount), 0);

    const expenses = monthlyTransactions
      .filter(t => t && t.type === "expense")
      .reduce((sum, t) => sum + safeNumber(t.amount), 0);

    return {
      income: safeNumber(income),
      expenses: safeNumber(expenses),
      balance: safeNumber(income - expenses)
    };
  };

  const getCategoryData = () => {
    if (!Array.isArray(transactions)) return [];

    const expenses = transactions.filter(t => t && t.type === "expense");
    const categoryTotals = {};

    expenses.forEach(t => {
      if (!t || !t.category) return;
      const amount = safeNumber(t.amount);
      categoryTotals[t.category] = safeNumber(categoryTotals[t.category]) + amount;
    });

    return Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category,
        amount: safeNumber(amount)
      }))
      .filter(item => item.amount > 0)
      .sort((a, b) => safeNumber(b.amount) - safeNumber(a.amount))
      .slice(0, 5);
  };

  const getMonthlyTrend = () => {
    if (!Array.isArray(transactions)) return [];

    const last6Months = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      const month = date.getMonth();
      const year = date.getFullYear();

      const monthTransactions = transactions.filter(t => {
        if (!t || !t.date) return false;
        try {
          const tDate = new Date(t.date);
          return tDate.getMonth() === month && tDate.getFullYear() === year;
        } catch {
          return false;
        }
      });

      const income = monthTransactions
        .filter(t => t && t.type === "income")
        .reduce((sum, t) => sum + safeNumber(t.amount), 0);

      const expenses = monthTransactions
        .filter(t => t && t.type === "expense")
        .reduce((sum, t) => sum + safeNumber(t.amount), 0);

      last6Months.push({
        month: date.toLocaleDateString('pt-BR', { month: 'short' }),
        receitas: safeNumber(income),
        despesas: safeNumber(expenses)
      });
    }
    return sanitizeChartData(last6Months);
  };

  const stats = getMonthlyStats();
  const categoryData = sanitizeChartData(getCategoryData());
  const monthlyTrend = getMonthlyTrend();

  const savingsRate = stats.income > 0
    ? ((stats.balance / stats.income) * 100)
    : 0;

  const COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6'];

  if (loading) {
    return (
      <div className="flex-1 p-8 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-slate-200 rounded w-64"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-32 bg-slate-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">
              Olá, {user?.full_name?.split(' ')[0] || 'Usuário'}! 👋
            </h1>
            <p className="text-slate-600 mt-1">
              Acompanhe suas finanças pessoais de forma inteligente
            </p>
          </div>
          <Button
            onClick={() => setShowTransactionForm(true)}
            className="bg-blue-500 hover:bg-blue-600"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Transação
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard
            title="Receitas do Mês"
            value={stats.income}
            prefix="R$ "
            icon={TrendingUp}
            color="bg-green-500"
            changeType="positive"
            change="+12.5%"
          />
          <StatsCard
            title="Despesas do Mês"
            value={stats.expenses}
            prefix="R$ "
            icon={Receipt}
            color="bg-red-500"
            changeType="negative"
            change="-8.2%"
          />
          <StatsCard
            title="Saldo do Mês"
            value={stats.balance}
            prefix="R$ "
            icon={DollarSign}
            color={stats.balance >= 0 ? "bg-green-500" : "bg-red-500"}
            changeType={stats.balance >= 0 ? "positive" : "negative"}
            change={stats.balance >= 0 ? "+15.3%" : "-5.7%"}
          />
          <StatsCard
            title="Metas Ativas"
            value={goals.filter(g => g && g.status === "active").length}
            icon={Target}
            color="bg-blue-500"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Tendência Mensal</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [`R$ ${formatCurrency(value)}`, '']}
                    labelFormatter={(label) => `Mês: ${label}`}
                  />
                  <Bar dataKey="receitas" fill="#10b981" name="Receitas" />
                  <Bar dataKey="despesas" fill="#ef4444" name="Despesas" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Despesas por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ category, percent }) => `${category} ${safeNumber(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="amount"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `R$ ${formatCurrency(value)}`} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions and Financial Health */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <QuickActions
            workspace="personal"
            onAction={handleQuickAction}
          />
          <RadialProgressCard
            title="Saúde Financeira"
            description="Taxa de Poupança Mensal"
            value={savingsRate}
            maxValue={20} // Target of 20%
            color="#3b82f6"
            unit="%"
          />
        </div>

        {/* Accounts and Debts Overview */}
        <AccountsOverview
          bankAccounts={bankAccounts}
          creditCards={creditCards}
          debts={debts}
        />

        {/* Transaction Form Modal */}
        {showTransactionForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="w-full max-w-md">
              <TransactionForm
                onSubmit={handleAddTransaction}
                onCancel={() => setShowTransactionForm(false)}
                workspace="personal"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
