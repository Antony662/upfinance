import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Heart, Link, Unlink, CheckCircle, Mail } from "lucide-react";

export default function CoupleSettingsPage() {
  const [user, setUser] = useState(null);
  const [partnerEmail, setPartnerEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      setPartnerEmail(userData.partner_email || "");
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleInvite = async () => {
    setMessage("");
    if (!partnerEmail) {
      setMessage("Por favor, insira o email do seu parceiro(a).");
      return;
    }

    try {
      await User.updateMyUserData({ partner_email: partnerEmail });
      setMessage("Convite enviado! Peça para seu parceiro(a) aceitar o convite no email dele(a).");
      loadUser();
    } catch (error) {
      setMessage("Erro ao enviar convite. Tente novamente.");
      console.error(error);
    }
  };

  const handleDisconnect = async () => {
    if (window.confirm("Tem certeza que deseja se desconectar do seu parceiro(a)? As finanças deixarão de ser compartilhadas.")) {
      try {
        await User.updateMyUserData({ partner_email: null, partner_connected: false });
        setMessage("Você foi desconectado(a).");
        loadUser();
      } catch (error) {
        setMessage("Erro ao desconectar. Tente novamente.");
        console.error(error);
      }
    }
  };

  if (loading) {
    return <div className="p-8">Carregando configurações...</div>;
  }

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Heart className="w-8 h-8 text-pink-500" />
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Configurações do Casal</h1>
            <p className="text-slate-600 mt-1">Conecte-se com seu parceiro(a) para gerenciar as finanças juntos.</p>
          </div>
        </div>

        {user.partner_connected ? (
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-800">
                <CheckCircle /> Conectado com Sucesso!
              </CardTitle>
              <CardDescription className="text-green-700">
                Você e {user.partner_email} estão conectados. Agora vocês podem gerenciar suas finanças e metas em conjunto.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={handleDisconnect} variant="destructive">
                <Unlink className="w-4 h-4 mr-2" />
                Desconectar
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Convidar Parceiro(a)</CardTitle>
              <CardDescription>
                {user.partner_email
                  ? `Um convite foi enviado para ${user.partner_email}. Aguardando aceitação.`
                  : "Insira o email do seu parceiro(a) para compartilhar o acesso às finanças do casal."}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="partner-email">Email do Parceiro(a)</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    id="partner-email"
                    type="email"
                    placeholder="email@do-parceiro.com"
                    value={partnerEmail}
                    onChange={(e) => setPartnerEmail(e.target.value)}
                    disabled={!!user.partner_email}
                  />
                </div>
              </div>
              {message && <Alert variant={message.includes("Erro") ? "destructive" : "default"}><AlertDescription>{message}</AlertDescription></Alert>}
              <Button onClick={handleInvite} disabled={!!user.partner_email}>
                <Link className="w-4 h-4 mr-2" />
                {user.partner_email ? "Reenviar Convite" : "Enviar Convite"}
              </Button>
              {user.partner_email && (
                 <Button onClick={handleDisconnect} variant="outline" className="ml-2">
                    Cancelar Convite
                 </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}