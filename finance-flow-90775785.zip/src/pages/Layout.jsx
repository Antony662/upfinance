

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  Home,
  Target,
  TrendingUp,
  Users,
  FileText,
  UserCheck,
  Receipt,
  Settings,
  Building2,
  User as UserIcon,
  Crown,
  ChevronDown,
  Heart,
  BarChart3,
  Landmark,
  Wallet,
  Calendar,
  Code,
  ShieldAlert
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const workspaceConfig = {
  personal: {
    name: "Pessoal",
    icon: UserIcon,
    color: "bg-blue-500",
    items: [
      { title: "Dashboard", url: "Dashboard", icon: Home },
      { title: "Transações", url: "Transactions", icon: Receipt },
      { title: "Contas", url: "Accounts", icon: Wallet },
      { title: "Dívidas", url: "Debts", icon: Landmark },
      { title: "Metas", url: "Goals", icon: Target },
      { title: "Limites de Gastos", url: "SpendingLimits", icon: ShieldAlert },
      { title: "Agenda", url: "Calendar", icon: Calendar },
      { title: "Relatórios", url: "Reports", icon: TrendingUp },
    ]
  },
  business: {
    name: "Empresarial",
    icon: Building2,
    color: "bg-indigo-600",
    items: [
      { title: "Dashboard", url: "BusinessDashboard", icon: Home },
      { title: "Transações", url: "BusinessTransactions", icon: Receipt },
      { title: "Contas", url: "Accounts", icon: Wallet },
      { title: "Dívidas", url: "Debts", icon: Landmark },
      { title: "Clientes", url: "Clients", icon: Users },
      { title: "Orçamentos", url: "Quotes", icon: FileText },
      { title: "Funcionários", url: "Employees", icon: UserCheck },
      { title: "Agenda", url: "BusinessCalendar", icon: Calendar },
      { title: "Relatórios", url: "BusinessReports", icon: TrendingUp },
      { title: "Limites de Gastos", url: "SpendingLimits", icon: ShieldAlert },
      { title: "Configurações", url: "CompanySettings", icon: Settings },
    ]
  },
  couple: {
    name: "Casal",
    icon: Heart,
    color: "bg-pink-500",
    items: [
      { title: "Dashboard", url: "CoupleDashboard", icon: Home },
      { title: "Transações", url: "CoupleTransactions", icon: Receipt },
      { title: "Contas", url: "Accounts", icon: Wallet },
      { title: "Dívidas", url: "Debts", icon: Landmark },
      { title: "Metas Conjuntas", url: "CoupleGoals", icon: Target },
      { title: "Limites de Gastos", url: "SpendingLimits", icon: ShieldAlert },
      { title: "Agenda", url: "CoupleCalendar", icon: Calendar },
      { title: "Relatórios", url: "CoupleReports", icon: TrendingUp },
      { title: "Configurações", url: "CoupleSettings", icon: Settings },
    ]
  }
};

const adminItems = [
  { title: "Painel Geral", url: "Admin", icon: Crown },
  { title: "Usuários", url: "AdminUsers", icon: Users },
  { title: "Relatórios", url: "AdminReports", icon: BarChart3 },
  { title: "API e Webhooks", url: "AdminApiWebhooks", icon: Code },
  { title: "Configurações", url: "AdminSettings", icon: Settings },
];

export default function Layout({ children, currentPageName }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [viewMode, setViewMode] = useState("user");
  const [currentWorkspace, setCurrentWorkspace] = useState("personal");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkUserAndRedirect = async () => {
      // Permite o acesso à página de setup sem autenticação completa
      if (currentPageName === 'WhatsappSetup') {
        setIsLoading(false);
        return;
      }

      try {
        const user = await User.me();

        // Redireciona para o setup do WhatsApp se não estiver completo
        if (!user.whatsapp_setup_complete) {
          window.location.href = createPageUrl('WhatsappSetup');
          return;
        }

        setCurrentUser(user);
        setIsAdmin(user.role === 'admin');
        setCurrentWorkspace(user.current_workspace || 'personal');
        if (currentPageName && currentPageName.startsWith('Admin')) {
            setViewMode("admin");
        } else {
            setViewMode("user");
        }

      } catch (error) {
        console.log("Usuário não logado ou erro na verificação.");
        // Em um app real, aqui você redirecionaria para a página de login.
        // Por enquanto, apenas paramos o loading.
      }
      setIsLoading(false);
    };

    checkUserAndRedirect();
  }, [currentPageName]);

  // Renderiza a página de setup sem o layout principal
  if (currentPageName === 'WhatsappSetup') {
    return <>{children}</>;
  }

  if (isLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-slate-100">
        <p>Carregando FinanceFlow...</p>
      </div>
    );
  }

  if (!currentUser) {
     return <div className="flex h-screen w-screen items-center justify-center bg-slate-100">
        <p>Por favor, faça o login para continuar.</p>
     </div>
  }

  const switchWorkspace = async (workspace) => {
    try {
      await User.updateMyUserData({ current_workspace: workspace });
      setCurrentWorkspace(workspace);
      setViewMode("user");

      const defaultPages = {
        personal: "Dashboard",
        business: "BusinessDashboard",
        couple: "CoupleDashboard"
      };

      window.location.href = createPageUrl(defaultPages[workspace]);
    } catch (error) {
      console.error("Erro ao trocar workspace:", error);
    }
  };

  const toggleViewMode = () => {
    const newMode = viewMode === "user" ? "admin" : "user";
    if (newMode === "admin") {
      window.location.href = createPageUrl("Admin");
    } else {
      const defaultPages = {
        personal: "Dashboard",
        business: "BusinessDashboard",
        couple: "CoupleDashboard"
      };
      window.location.href = createPageUrl(defaultPages[currentWorkspace]);
    }
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      // Optionally redirect to login page after logout
      window.location.href = createPageUrl("Login"); // Assuming a Login page
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  const currentConfig = workspaceConfig[currentWorkspace];

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-50">
        <Sidebar className="border-r border-slate-200 bg-white w-72 hidden lg:block">
          <SidebarHeader className="border-b border-slate-200 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 text-lg">FinanceFlow</h2>
                <p className="text-xs text-slate-500">
                  {viewMode === "admin" ? "Painel Administrativo" : "Gestão Financeira Inteligente"}
                </p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-4 space-y-4">
            {isAdmin && (
              <SidebarGroup>
                <SidebarGroupLabel className="flex items-center justify-between px-2">
                  <span>Modo de Visualização</span>
                  <Button variant="outline" size="sm" onClick={toggleViewMode}>
                    {viewMode === "user" ? "Admin" : "Usuário"}
                  </Button>
                </SidebarGroupLabel>
              </SidebarGroup>
            )}

            {viewMode === 'user' ? (
              <>
                <SidebarGroup>
                  <SidebarGroupLabel className="px-2 mb-3">Workspace</SidebarGroupLabel>
                  <SidebarGroupContent>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="w-full justify-between h-10">
                          <div className="flex items-center gap-2">
                             <div className={`w-3 h-3 rounded-full ${currentConfig.color}`} />
                             <currentConfig.icon className="w-4 h-4" />
                             <span className="font-medium">{currentConfig.name}</span>
                          </div>
                          <ChevronDown className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-64">
                        <DropdownMenuItem onClick={() => switchWorkspace("personal")} className="flex items-center gap-2 p-3">
                          <UserIcon className="w-4 h-4" />
                          <span>Pessoal</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => switchWorkspace("business")} className="flex items-center gap-2 p-3">
                          <Building2 className="w-4 h-4" />
                          <span>Empresarial</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => switchWorkspace("couple")} className="flex items-center gap-2 p-3">
                          <Heart className="w-4 h-4" />
                          <span>Casal</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </SidebarGroupContent>
                </SidebarGroup>

                <SidebarGroup>
                  <SidebarGroupLabel className="px-2 mb-3">Menu Principal</SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu className="space-y-1">
                      {currentConfig.items.map((item) => (
                        <SidebarMenuItem key={item.url}>
                          <SidebarMenuButton asChild isActive={currentPageName === item.url}>
                            <Link to={createPageUrl(item.url)} className="flex items-center gap-3 px-3 py-2 rounded-lg">
                              <item.icon className="w-4 h-4" />
                              <span className="font-medium">{item.title}</span>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </>
            ) : (
              <SidebarGroup>
                <SidebarGroupLabel className="px-2 mb-3">Administração</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu className="space-y-1">
                    {adminItems.map((item) => (
                      <SidebarMenuItem key={item.url}>
                        <SidebarMenuButton asChild isActive={currentPageName === item.url}>
                          <Link to={createPageUrl(item.url)} className="flex items-center gap-3 px-3 py-2 rounded-lg">
                            <item.icon className="w-4 h-4" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            )}
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-200 p-4">
             <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-12">
                    <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
                      <UserIcon className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                       <p className="text-sm font-medium text-slate-800">{currentUser.full_name}</p>
                       <p className="text-xs text-slate-500">{currentUser.email}</p>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56">
                  <DropdownMenuItem>Meu Perfil</DropdownMenuItem>
                  <DropdownMenuItem>Configurações</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-500">
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
             </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        {/* Mobile Sidebar Overlay */}
        <div className="lg:hidden">
          <SidebarTrigger className="fixed top-4 left-4 z-50 bg-white border shadow-sm" />
        </div>

        <main className="flex-1 overflow-auto lg:ml-0">
          <div className="lg:hidden h-16"></div> {/* Spacer for mobile trigger */}
          {children}
        </main>
      </div>
    </SidebarProvider>
  );
}

