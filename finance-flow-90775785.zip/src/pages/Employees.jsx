import React, { useState, useEffect } from "react";
import { Employee } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, User, Edit, Trash2, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const EmployeeForm = ({ employee, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    name: employee?.name || "",
    email: employee?.email || "",
    phone: employee?.phone || "",
    position: employee?.position || "",
    salary: employee?.salary || "",
    contract_type: employee?.contract_type || "clt",
    payment_frequency: employee?.payment_frequency || "monthly",
    hire_date: employee?.hire_date || new Date().toISOString().split('T')[0]
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      salary: parseFloat(formData.salary)
    });
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>{employee ? 'Editar Funcionário' : 'Novo Funcionário'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Nome</label>
              <input 
                value={formData.name}
                onChange={e => setFormData(prev => ({...prev, name: e.target.value}))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input 
                type="email"
                value={formData.email}
                onChange={e => setFormData(prev => ({...prev, email: e.target.value}))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Telefone</label>
              <input 
                value={formData.phone}
                onChange={e => setFormData(prev => ({...prev, phone: e.target.value}))}
                className="w-full p-2 border rounded"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Cargo</label>
              <input 
                value={formData.position}
                onChange={e => setFormData(prev => ({...prev, position: e.target.value}))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Salário</label>
              <input 
                type="number"
                step="0.01"
                value={formData.salary}
                onChange={e => setFormData(prev => ({...prev, salary: e.target.value}))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Tipo de Contrato</label>
              <select 
                value={formData.contract_type}
                onChange={e => setFormData(prev => ({...prev, contract_type: e.target.value}))}
                className="w-full p-2 border rounded"
              >
                <option value="clt">CLT</option>
                <option value="freelancer">Freelancer</option>
                <option value="intern">Estagiário</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Frequência de Pagamento</label>
              <select 
                value={formData.payment_frequency}
                onChange={e => setFormData(prev => ({...prev, payment_frequency: e.target.value}))}
                className="w-full p-2 border rounded"
              >
                <option value="monthly">Mensal</option>
                <option value="weekly">Semanal</option>
                <option value="hourly">Por Hora</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Data de Contratação</label>
              <input 
                type="date"
                value={formData.hire_date}
                onChange={e => setFormData(prev => ({...prev, hire_date: e.target.value}))}
                className="w-full p-2 border rounded"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">Salvar</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default function EmployeesPage() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const data = await Employee.list("-created_date");
      setEmployees(data);
    } catch (error) {
      console.error("Erro ao carregar funcionários:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async (data) => {
    try {
      if (editingEmployee) {
        await Employee.update(editingEmployee.id, data);
      } else {
        await Employee.create(data);
      }
      setShowForm(false);
      setEditingEmployee(null);
      loadEmployees();
    } catch (error) {
      console.error("Erro ao salvar funcionário:", error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir este funcionário?")) {
      try {
        await Employee.delete(id);
        loadEmployees();
      } catch (error) {
        console.error("Erro ao excluir funcionário:", error);
      }
    }
  };

  const getContractTypeBadge = (type) => {
    const config = {
      clt: { label: "CLT", className: "bg-blue-100 text-blue-800" },
      freelancer: { label: "Freelancer", className: "bg-green-100 text-green-800" },
      intern: { label: "Estagiário", className: "bg-purple-100 text-purple-800" }
    };
    const { label, className } = config[type] || config.clt;
    return <Badge className={className}>{label}</Badge>;
  };

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Funcionários</h1>
            <p className="text-slate-600 mt-1">Gerencie sua equipe e folha de pagamento.</p>
          </div>
          <Button onClick={() => { setEditingEmployee(null); setShowForm(true); }} className="bg-indigo-600 hover:bg-indigo-700">
            <Plus className="w-4 h-4 mr-2" />
            Novo Funcionário
          </Button>
        </div>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Lista de Funcionários</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Cargo</TableHead>
                  <TableHead>Contrato</TableHead>
                  <TableHead>Salário</TableHead>
                  <TableHead>Contratação</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan="7">Carregando...</TableCell></TableRow>
                ) : employees.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center">
                          <User className="w-4 h-4 text-slate-500" />
                        </div>
                        <div>
                          <div className="font-medium">{employee.name}</div>
                          <div className="text-sm text-slate-500">{employee.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{employee.position}</TableCell>
                    <TableCell>{getContractTypeBadge(employee.contract_type)}</TableCell>
                    <TableCell className="font-semibold">R$ {employee.salary?.toFixed(2)}</TableCell>
                    <TableCell>{format(new Date(employee.hire_date), "dd/MM/yyyy", { locale: ptBR })}</TableCell>
                    <TableCell>
                      <Badge className={employee.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                        {employee.status === 'active' ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon">
                          <DollarSign className="w-4 h-4 text-green-500" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => { setEditingEmployee(employee); setShowForm(true); }}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(employee.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <EmployeeForm
              employee={editingEmployee}
              onSubmit={handleFormSubmit}
              onCancel={() => { setShowForm(false); setEditingEmployee(null); }}
            />
          </div>
        )}
      </div>
    </div>
  );
}