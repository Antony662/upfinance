import React, { useState, useEffect } from 'react';
import { SpendingLimit } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, ShieldAlert } from 'lucide-react';
import SpendingLimitForm from '../components/forms/SpendingLimitForm';
import { formatCurrency } from '../components/utils/safeNumbers';

export default function SpendingLimitsPage() {
  const [limits, setLimits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingLimit, setEditingLimit] = useState(null);
  const [currentWorkspace, setCurrentWorkspace] = useState('personal');

  useEffect(() => {
    const fetchUserAndLimits = async () => {
      try {
        const user = await User.me();
        const workspace = user.current_workspace || 'personal';
        setCurrentWorkspace(workspace);
        loadLimits(workspace);
      } catch (error) {
        console.error("Erro ao buscar usuário:", error);
        setLoading(false);
      }
    };
    fetchUserAndLimits();
  }, []);

  const loadLimits = async (workspace) => {
    setLoading(true);
    try {
      const data = await SpendingLimit.filter({ workspace });
      setLimits(data);
    } catch (error) {
      console.error("Erro ao carregar limites:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async (data) => {
    try {
      if (editingLimit) {
        await SpendingLimit.update(editingLimit.id, data);
      } else {
        await SpendingLimit.create({ ...data, workspace: currentWorkspace });
      }
      setShowForm(false);
      setEditingLimit(null);
      loadLimits(currentWorkspace);
    } catch (error) {
      console.error("Erro ao salvar limite:", error);
    }
  };

  const handleEdit = (limit) => {
    setEditingLimit(limit);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir este limite?")) {
      await SpendingLimit.delete(id);
      loadLimits(currentWorkspace);
    }
  };

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-8 h-8 text-blue-600" />
              Limites de Gastos
            </h1>
            <p className="text-slate-600 mt-1">Defina orçamentos para não gastar mais do que o planejado.</p>
          </div>
          <Button onClick={() => { setEditingLimit(null); setShowForm(true); }} className="bg-blue-500 hover:bg-blue-600">
            <Plus className="w-4 h-4 mr-2" />
            Novo Limite
          </Button>
        </div>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Limites Ativos para o Workspace "{currentWorkspace}"</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Valor do Limite</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead className="text-center">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan="4" className="text-center p-4">Carregando...</TableCell></TableRow>
                ) : limits.map((limit) => (
                  <TableRow key={limit.id}>
                    <TableCell>
                      <Badge variant={limit.category ? "default" : "secondary"}>
                        {limit.category || "Todos os Gastos"}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-semibold">{formatCurrency(limit.limit_amount)}</TableCell>
                    <TableCell>{limit.period === 'monthly' ? 'Mensal' : 'Semanal'}</TableCell>
                    <TableCell className="text-center">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(limit)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(limit.id)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="w-full max-w-md">
              <SpendingLimitForm
                limit={editingLimit}
                onSubmit={handleFormSubmit}
                onCancel={() => { setShowForm(false); setEditingLimit(null); }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}