
import React, { useState, useEffect } from "react";
import { Quote, Client } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, FileText, Edit, Send, Check, X, Trash2, MoreHorizontal, FilePenLine } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { generateQuotePDF } from "@/api/functions";
import { triggerWebhook } from "@/api/functions";

const QuoteForm = ({ quote, onSubmit, onCancel }) => {
  const [clients, setClients] = useState([]);
  const [formData, setFormData] = useState({
    client_id: quote?.client_id || "",
    title: quote?.title || "",
    description: quote?.description || "",
    items: quote?.items || [{ description: "", quantity: 1, unit_price: 0, total: 0 }],
    valid_until: quote?.valid_until || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  });

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    const data = await Client.list();
    setClients(data);
  };

  const addItem = () => {
    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { description: "", quantity: 1, unit_price: 0, total: 0 }]
    }));
  };

  const updateItem = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = value;
    if (field === 'quantity' || field === 'unit_price') {
      newItems[index].total = newItems[index].quantity * newItems[index].unit_price;
    }
    setFormData(prev => ({ ...prev, items: newItems }));
  };

  const removeItem = (index) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
  };

  const getTotalAmount = () => {
    return formData.items.reduce((sum, item) => sum + item.total, 0);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      total_amount: getTotalAmount(),
      quote_number: quote?.quote_number || `ORÇ-${Date.now()}` // Client-side temp number, backend should assign final.
    });
  };

  return (
    <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
      <CardHeader>
        <CardTitle>{quote ? 'Editar Orçamento' : 'Novo Orçamento'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Cliente</label>
              <select
                value={formData.client_id}
                onChange={e => setFormData(prev => ({ ...prev, client_id: e.target.value }))}
                className="w-full p-2 border rounded"
                required
              >
                <option value="">Selecione um cliente</option>
                {clients.map(client => (
                  <option key={client.id} value={client.id}>{client.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Válido até</label>
              <input
                type="date"
                value={formData.valid_until}
                onChange={e => setFormData(prev => ({ ...prev, valid_until: e.target.value }))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Título</label>
            <input
              value={formData.title}
              onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
              className="w-full p-2 border rounded"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Descrição</label>
            <textarea
              value={formData.description}
              onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="w-full p-2 border rounded h-20"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Itens do Orçamento</h3>
              <Button type="button" onClick={addItem} size="sm">
                <Plus className="w-4 h-4 mr-2" />Adicionar Item
              </Button>
            </div>

            <div className="space-y-3">
              {formData.items.map((item, index) => (
                <div key={index} className="grid grid-cols-12 gap-2 items-center p-3 border rounded">
                  <input
                    placeholder="Descrição do item"
                    value={item.description}
                    onChange={e => updateItem(index, 'description', e.target.value)}
                    className="col-span-5 p-2 border rounded"
                  />
                  <input
                    type="number"
                    placeholder="Qtd"
                    value={item.quantity}
                    onChange={e => updateItem(index, 'quantity', parseFloat(e.target.value) || 0)}
                    className="col-span-2 p-2 border rounded"
                  />
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Preço unit."
                    value={item.unit_price}
                    onChange={e => updateItem(index, 'unit_price', parseFloat(e.target.value) || 0)}
                    className="col-span-2 p-2 border rounded"
                  />
                  <div className="col-span-2 text-center font-medium">
                    R$ {item.total.toFixed(2)}
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeItem(index)}
                    className="col-span-1"
                  >
                    <X className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              ))}
            </div>

            <div className="text-right text-xl font-bold mt-4">
              Total: R$ {getTotalAmount().toFixed(2)}
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">Salvar Orçamento</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default function QuotesPage() {
  const [quotes, setQuotes] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingQuote, setEditingQuote] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [quotesData, clientsData] = await Promise.all([
        Quote.list("-created_date"),
        Client.list()
      ]);
      setQuotes(quotesData);
      setClients(clientsData);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async (data) => {
    try {
      let resultQuote;
      if (editingQuote) {
        resultQuote = await Quote.update(editingQuote.id, data);
      } else {
        resultQuote = await Quote.create(data);
        // Trigger webhook for quote creation
        await triggerWebhook({
          event: 'quote.created',
          payload: resultQuote
        });
      }
      setShowForm(false);
      setEditingQuote(null);
      loadData();
    } catch (error) {
      console.error("Erro ao salvar orçamento:", error);
    }
  };

  const handleAcceptQuote = async (quote) => {
    try {
      const updatedQuote = await Quote.update(quote.id, { status: 'accepted' });
      
      // Generate PDF - this `generateQuotePDF` is the imported function that makes an API call
      const { data: pdfData } = await generateQuotePDF({ quoteId: quote.id });
      
      // Trigger webhook with updated quote data and PDF generation status
      await triggerWebhook({
        event: 'quote.accepted',
        payload: {
          ...updatedQuote,
          pdf_generated: true,
          message: `Orçamento ${updatedQuote.quote_number} foi aceito! PDF em anexo.`
        }
      });
      
      loadData();
    } catch (error) {
      console.error("Erro ao aceitar orçamento:", error);
      alert("Erro ao aceitar orçamento. Tente novamente.");
    }
  };

  const updateQuoteStatus = async (quoteId, status) => {
    try {
      await Quote.update(quoteId, { status });
      loadData();
    } catch (error) {
      console.error("Erro ao atualizar status:", error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir este orçamento? Esta ação não pode ser desfeita.")) {
      try {
        await Quote.delete(id);
        loadData();
      } catch (error) {
        console.error("Erro ao excluir orçamento:", error);
        alert("Não foi possível excluir o orçamento.");
      }
    }
  };

  const generatePDF = async (quote) => {
    try {
      // This `generateQuotePDF` is the imported function that makes an API call
      const { data } = await generateQuotePDF({ quoteId: quote.id });
      const blob = new Blob([data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `orcamento-${quote.quote_number}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      alert("Erro ao gerar PDF. Tente novamente.");
    }
  };

  const getClientName = (clientId) => {
    const client = clients.find(c => c.id === clientId);
    return client?.name || "Cliente não encontrado";
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      draft: { label: "Rascunho", className: "bg-gray-200 text-gray-800" },
      sent: { label: "Enviado", className: "bg-blue-100 text-blue-800" },
      accepted: { label: "Aceito", className: "bg-green-100 text-green-800" },
      rejected: { label: "Rejeitado", className: "bg-red-100 text-red-800" }
    };

    const config = statusConfig[status] || statusConfig.draft;
    return <Badge variant="outline" className={`border-transparent ${config.className}`}>{config.label}</Badge>;
  };

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Orçamentos</h1>
            <p className="text-slate-600 mt-1">Gerencie propostas e orçamentos para seus clientes.</p>
          </div>
          <Button onClick={() => { setEditingQuote(null); setShowForm(true); }} className="bg-indigo-600 hover:bg-indigo-700">
            <Plus className="w-4 h-4 mr-2" />
            Novo Orçamento
          </Button>
        </div>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Lista de Orçamentos</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Número</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Válido até</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan="7">Carregando...</TableCell></TableRow>
                ) : quotes.map((quote) => (
                  <TableRow key={quote.id}>
                    <TableCell className="font-mono">{quote.quote_number}</TableCell>
                    <TableCell>{getClientName(quote.client_id)}</TableCell>
                    <TableCell>{quote.title}</TableCell>
                    <TableCell className="font-semibold">R$ {quote.total_amount?.toFixed(2)}</TableCell>
                    <TableCell>{getStatusBadge(quote.status)}</TableCell>
                    <TableCell>{format(new Date(quote.valid_until), "dd/MM/yyyy", { locale: ptBR })}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditingQuote(quote); setShowForm(true); }}>
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Editar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => generatePDF(quote)}>
                            <FileText className="mr-2 h-4 w-4" />
                            <span>Gerar PDF</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          
                          {/* Status Manual */}
                          <DropdownMenuItem onClick={() => updateQuoteStatus(quote.id, 'draft')}>
                            <FilePenLine className="mr-2 h-4 w-4 text-gray-500" />
                            <span>Rascunho</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => updateQuoteStatus(quote.id, 'sent')}>
                            <Send className="mr-2 h-4 w-4 text-blue-500" />
                            <span>Enviado</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAcceptQuote(quote)}>
                            <Check className="mr-2 h-4 w-4 text-green-500" />
                            <span>Aceito</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => updateQuoteStatus(quote.id, 'rejected')}>
                            <X className="mr-2 h-4 w-4 text-red-500" />
                            <span>Rejeitado</span>
                          </DropdownMenuItem>
                          
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDelete(quote.id)} className="text-red-500 focus:text-red-500 focus:bg-red-50">
                            <Trash2 className="mr-2 h-4 w-4" />
                            <span>Excluir</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <QuoteForm
              quote={editingQuote}
              onSubmit={handleFormSubmit}
              onCancel={() => { setShowForm(false); setEditingQuote(null); }}
            />
          </div>
        )}
      </div>
    </div>
  );
}
