
import React, { useState, useEffect } from "react";
import { Transaction } from "@/api/entities";
import { BankAccount } from "@/api/entities";
import { CreditCard } from "@/api/entities";
import { Debt } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, AreaChart, Area, RadarChart,
  PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ComposedChart
} from "recharts";
import {
  Download, Calendar, TrendingUp, DollarSign, FileText, User,
  Target, Award, AlertTriangle, Activity, ArrowUp, ArrowDown,
  PieChart as PieChartIcon, BarChart3, TrendingDown, Eye, Zap,
  CreditCard as CreditCardIcon, Landmark, Wallet, Heart
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, startOfYear, endOfYear, subDays, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { safeNumber, safePercent, formatCurrency } from "../components/utils/safeNumbers";

export default function ReportsPage() {
  const [transactions, setTransactions] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [creditCards, setCreditCards] = useState([]);
  const [debts, setDebts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState("3months");
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [transactionsData, accountsData, cardsData, debtsData] = await Promise.all([
        Transaction.filter({ workspace: "personal" }),
        BankAccount.filter({ workspace: "personal" }),
        CreditCard.filter({ workspace: "personal" }),
        Debt.filter({ workspace: "personal" })
      ]);
      setTransactions(Array.isArray(transactionsData) ? transactionsData : []);
      setBankAccounts(Array.isArray(accountsData) ? accountsData : []);
      setCreditCards(Array.isArray(cardsData) ? cardsData : []);
      setDebts(Array.isArray(debtsData) ? debtsData : []);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      setTransactions([]);
      setBankAccounts([]);
      setCreditCards([]);
      setDebts([]);
    } finally {
      setLoading(false);
    }
  };

  const getMonthlyReport = () => {
    const months = [];
    const numMonths = selectedPeriod === "6months" ? 6 : selectedPeriod === "12months" ? 12 : 3;
    
    for (let i = numMonths - 1; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const monthStart = startOfMonth(date);
      const monthEnd = endOfMonth(date);
      
      const monthTransactions = transactions.filter(t => {
        if (!t || !t.date) return false;
        try {
          const tDate = new Date(t.date);
          return tDate >= monthStart && tDate <= monthEnd;
        } catch {
          return false;
        }
      });

      const income = monthTransactions
        .filter(t => t && t.type === "income")
        .reduce((sum, t) => sum + safeNumber(t.amount), 0);

      const expenses = monthTransactions
        .filter(t => t && t.type === "expense")
        .reduce((sum, t) => sum + safeNumber(t.amount), 0);

      const savings = income - expenses;
      const savingsRate = income > 0 ? safePercent(savings, income) : 0;

      months.push({
        month: format(date, "MMM/yy", { locale: ptBR }),
        receitas: safeNumber(income),
        despesas: safeNumber(expenses),
        saldo: safeNumber(savings),
        taxaPoupanca: safeNumber(savingsRate),
        eficiencia: expenses > 0 ? Math.min(100, safeNumber((income / expenses) * 50)) : 100
      });
    }
    return months;
  };

  const getDailyTrend = () => {
    const last30Days = [];
    for (let i = 29; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayTransactions = transactions.filter(t => {
        if (!t || !t.date) return false;
        try {
          const tDate = new Date(t.date);
          return tDate.toDateString() === date.toDateString();
        } catch {
          return false;
        }
      });

      const income = dayTransactions
        .filter(t => t && t.type === "income")
        .reduce((sum, t) => sum + safeNumber(t.amount), 0);

      const expenses = dayTransactions
        .filter(t => t && t.type === "expense")
        .reduce((sum, t) => sum + safeNumber(t.amount), 0);

      last30Days.push({
        date: format(date, "dd/MM", { locale: ptBR }),
        receitas: safeNumber(income),
        despesas: safeNumber(expenses),
        saldoDiario: safeNumber(income - expenses),
        transacoes: dayTransactions.length
      });
    }
    return last30Days;
  };

  const getCategoryAnalysis = () => {
    const expenses = transactions.filter(t => t && t.type === "expense");
    const income = transactions.filter(t => t && t.type === "income");
    
    const expenseCategories = {};
    const incomeCategories = {};
    
    expenses.forEach(t => {
      if (!t || !t.category) return;
      const amount = safeNumber(t.amount);
      expenseCategories[t.category] = safeNumber(expenseCategories[t.category]) + amount;
    });
    
    income.forEach(t => {
      if (!t || !t.category) return;
      const amount = safeNumber(t.amount);
      incomeCategories[t.category] = safeNumber(incomeCategories[t.category]) + amount;
    });

    const totalExpenses = Object.values(expenseCategories).reduce((a, b) => safeNumber(a) + safeNumber(b), 0);
    const totalIncome = Object.values(incomeCategories).reduce((a, b) => safeNumber(a) + safeNumber(b), 0);

    const expenseData = Object.entries(expenseCategories)
      .map(([category, amount]) => ({ 
        name: category, 
        value: safeNumber(amount),
        type: 'despesa',
        percentage: totalExpenses > 0 ? safePercent(amount, totalExpenses).toFixed(1) : '0.0'
      }))
      .sort((a, b) => safeNumber(b.value) - safeNumber(a.value));

    const incomeData = Object.entries(incomeCategories)
      .map(([category, amount]) => ({ 
        name: category, 
        value: safeNumber(amount),
        type: 'receita',
        percentage: totalIncome > 0 ? safePercent(amount, totalIncome).toFixed(1) : '0.0'
      }))
      .sort((a, b) => safeNumber(b.value) - safeNumber(a.value));

    return { expenseData, incomeData };
  };

  const getFinancialHealth = () => {
    const totalIncome = transactions
      .filter(t => t && t.type === "income")
      .reduce((sum, t) => sum + safeNumber(t.amount), 0);
    
    const totalExpenses = transactions
      .filter(t => t && t.type === "expense")
      .reduce((sum, t) => sum + safeNumber(t.amount), 0);

    const totalDebt = debts.reduce((sum, d) => {
      if (!d) return sum;
      const total = safeNumber(d.total_amount);
      const paid = safeNumber(d.paid_amount);
      return sum + Math.max(0, total - paid);
    }, 0);
    
    const monthlyDebtPayments = debts.reduce((sum, d) => {
      return sum + safeNumber(d?.installment_amount);
    }, 0);
    
    const savingsRate = totalIncome > 0 ? safePercent(totalIncome - totalExpenses, totalIncome) : 0;
    const debtToIncomeRatio = totalIncome > 0 ? safePercent(monthlyDebtPayments * 12, totalIncome) : 0;
    
    const totalBalance = bankAccounts.reduce((sum, acc) => {
      return sum + safeNumber(acc?.initial_balance);
    }, 0);
    
    const monthlyExpenses = totalExpenses / 12;
    const liquidityRatio = monthlyExpenses > 0 ? Math.min(100, safeNumber((totalBalance / monthlyExpenses) * 10)) : 100;

    return [
      { metric: 'Taxa de Poupança', value: Math.min(100, Math.max(0, safeNumber(savingsRate))), fullMark: 100 },
      { metric: 'Controle de Gastos', value: totalExpenses > 0 ? Math.min(100, safeNumber((totalIncome / totalExpenses) * 50)) : 100, fullMark: 100 },
      { metric: 'Liquidez', value: Math.min(100, safeNumber(liquidityRatio)), fullMark: 100 },
      { metric: 'Endividamento', value: Math.max(0, 100 - safeNumber(debtToIncomeRatio)), fullMark: 100 },
      { metric: 'Diversificação', value: 75, fullMark: 100 },
    ];
  };

  const getPaymentMethodAnalysis = () => {
    const methods = {};
    transactions.forEach(t => {
      if (!t || !t.payment_method) return;
      const amount = safeNumber(t.amount);
      methods[t.payment_method] = safeNumber(methods[t.payment_method]) + amount;
    });

    const methodLabels = {
      debit: 'Débito/Conta',
      credit_card: 'Cartão de Crédito',
      pix: 'PIX',
      cash: 'Dinheiro'
    };

    const totalAmount = Object.values(methods).reduce((a, b) => safeNumber(a) + safeNumber(b), 0);

    return Object.entries(methods).map(([method, amount]) => ({
      name: methodLabels[method] || method,
      value: safeNumber(amount),
      percentage: totalAmount > 0 ? safePercent(amount, totalAmount).toFixed(1) : '0.0'
    }));
  };

  const getSummaryStats = () => {
    const totalIncome = transactions
      .filter(t => t && t.type === "income")
      .reduce((sum, t) => sum + safeNumber(t.amount), 0);
    
    const totalExpenses = transactions
      .filter(t => t && t.type === "expense")
      .reduce((sum, t) => sum + safeNumber(t.amount), 0);

    const netBalance = totalIncome - totalExpenses;
    const savingsRate = totalIncome > 0 ? safePercent(netBalance, totalIncome) : 0;
    
    const totalDebt = debts.reduce((sum, d) => {
      if (!d) return sum;
      const total = safeNumber(d.total_amount);
      const paid = safeNumber(d.paid_amount);
      return sum + Math.max(0, total - paid);
    }, 0);
    
    const totalAssets = bankAccounts.reduce((sum, acc) => {
      return sum + safeNumber(acc?.initial_balance);
    }, 0) + netBalance;
    
    const netWorth = totalAssets - totalDebt;

    return {
      totalIncome: safeNumber(totalIncome),
      totalExpenses: safeNumber(totalExpenses),
      netBalance: safeNumber(netBalance),
      savingsRate: safeNumber(savingsRate),
      totalDebt: safeNumber(totalDebt),
      totalAssets: safeNumber(totalAssets),
      netWorth: safeNumber(netWorth),
    };
  };

  const monthlyData = getMonthlyReport();
  const dailyData = getDailyTrend();
  const { expenseData, incomeData } = getCategoryAnalysis();
  const summaryStats = getSummaryStats();
  const healthData = getFinancialHealth();
  const paymentData = getPaymentMethodAnalysis();

  const COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

  if (loading) {
    return (
      <div className="flex-1 p-8 bg-slate-50">
        <div className="text-center py-16">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando análises financeiras...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Relatórios Pessoais</h1>
              <p className="text-slate-600 mt-1">Análise completa da sua saúde financeira pessoal.</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3months">Últimos 3 meses</SelectItem>
                <SelectItem value="6months">Últimos 6 meses</SelectItem>
                <SelectItem value="12months">Últimos 12 meses</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Enhanced Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="border-0 shadow-sm bg-gradient-to-br from-green-50 to-green-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-green-200 opacity-20 rounded-full transform translate-x-8 -translate-y-8"></div>
            <CardContent className="p-6 relative z-10">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 font-medium">Patrimônio Líquido</p>
                  <p className={`text-2xl font-bold ${summaryStats.netWorth >= 0 ? 'text-green-900' : 'text-red-900'}`}>
                    R$ {formatCurrency(summaryStats.netWorth)}
                  </p>
                  <div className="flex items-center gap-1 mt-1">
                    {summaryStats.netBalance >= 0 ? (
                      <ArrowUp className="w-4 h-4 text-green-600" />
                    ) : (
                      <ArrowDown className="w-4 h-4 text-red-600" />
                    )}
                    <span className="text-sm text-green-600">Ativos - Dívidas</span>
                  </div>
                </div>
                <Wallet className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-sm bg-gradient-to-br from-blue-50 to-blue-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-200 opacity-20 rounded-full transform translate-x-8 -translate-y-8"></div>
            <CardContent className="p-6 relative z-10">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-700 font-medium">Taxa de Poupança</p>
                  <p className={`text-2xl font-bold ${summaryStats.savingsRate >= 0 ? 'text-blue-900' : 'text-red-900'}`}>
                    {safeNumber(summaryStats.savingsRate).toFixed(1)}%
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Progress value={Math.max(0, safeNumber(summaryStats.savingsRate))} className="flex-1 h-2" />
                    <span className="text-xs text-blue-600">Meta: 20%</span>
                  </div>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-sm bg-gradient-to-br from-purple-50 to-purple-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-200 opacity-20 rounded-full transform translate-x-8 -translate-y-8"></div>
            <CardContent className="p-6 relative z-10">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-700 font-medium">Dívidas Totais</p>
                  <p className="text-2xl font-bold text-purple-900">
                    R$ {formatCurrency(summaryStats.totalDebt)}
                  </p>
                  <p className="text-sm text-purple-600">
                    {debts.length} dívida{debts.length !== 1 ? 's' : ''} ativa{debts.length !== 1 ? 's' : ''}
                  </p>
                </div>
                <Landmark className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Advanced Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white shadow-sm">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visão Geral
            </TabsTrigger>
            <TabsTrigger value="expenses" className="flex items-center gap-2">
              <PieChartIcon className="w-4 h-4" />
              Despesas
            </TabsTrigger>
            <TabsTrigger value="health" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Saúde Financeira
            </TabsTrigger>
            <TabsTrigger value="insights" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Insights
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                    Evolução Patrimonial
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <ComposedChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value, name) => [
                          `R$ ${safeNumber(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 
                          name === 'saldo' ? 'Saldo Mensal' : name === 'receitas' ? 'Receitas' : 'Despesas'
                        ]} 
                      />
                      <Area type="monotone" dataKey="receitas" fill="#10b981" fillOpacity={0.3} stroke="#10b981" strokeWidth={2} />
                      <Area type="monotone" dataKey="despesas" fill="#ef4444" fillOpacity={0.3} stroke="#ef4444" strokeWidth={2} />
                      <Line type="monotone" dataKey="saldo" stroke="#3b82f6" strokeWidth={3} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-600" />
                    Fluxo Diário (30 dias)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={dailyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`R$ ${safeNumber(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, '']} />
                      <Area type="monotone" dataKey="saldoDiario" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Payment Methods Analysis */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCardIcon className="w-5 h-5 text-blue-600" />
                  Análise de Métodos de Pagamento
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={paymentData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        innerRadius={40}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percentage }) => `${name} ${percentage}%`}
                      >
                        {paymentData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `R$ ${safeNumber(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-4">
                    {paymentData.map((method, index) => (
                      <div key={method.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full`} style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                          <span className="font-medium">{method.name}</span>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">R$ {formatCurrency(method.value)}</div>
                          <div className="text-sm text-slate-500">{method.percentage}%</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Expenses Tab */}
          <TabsContent value="expenses" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChartIcon className="w-5 h-5 text-red-600" />
                    Despesas por Categoria
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={expenseData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        innerRadius={40}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percentage }) => `${name} ${percentage}%`}
                      >
                        {expenseData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `R$ ${safeNumber(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-green-600" />
                    Receitas por Categoria
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={incomeData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`R$ ${safeNumber(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 'Receita']} />
                      <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Category Details */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-red-600">Maiores Despesas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {expenseData.slice(0, 5).map((category, index) => (
                    <div key={category.name} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-red-600 text-sm font-bold">
                          {index + 1}
                        </div>
                        <span className="font-medium">{category.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-red-700">R$ {formatCurrency(category.value)}</div>
                        <div className="text-sm text-red-500">{category.percentage}% do total</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-green-600">Principais Receitas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {incomeData.slice(0, 5).map((category, index) => (
                    <div key={category.name} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-green-600 text-sm font-bold">
                          {index + 1}
                        </div>
                        <span className="font-medium">{category.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-700">R$ {formatCurrency(category.value)}</div>
                        <div className="text-sm text-green-500">{category.percentage}% do total</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Health Tab */}
          <TabsContent value="health" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-green-600" />
                    Radar de Saúde Financeira
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={healthData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="metric" />
                      <PolarRadiusAxis angle={90} domain={[0, 100]} />
                      <Radar name="Saúde Financeira" dataKey="value" stroke="#10b981" fill="#10b981" fillOpacity={0.3} strokeWidth={2} />
                      <Tooltip />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-green-600" />
                    Indicadores Chave
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {healthData.map((indicator, index) => (
                    <div key={indicator.metric} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{indicator.metric}</span>
                        <span className="text-sm font-bold">{safeNumber(indicator.value).toFixed(1)}%</span>
                      </div>
                      <Progress value={safeNumber(indicator.value)} className="h-2" />
                      <div className="text-xs text-slate-500">
                        {indicator.value >= 80 ? '✅ Excelente' :
                         indicator.value >= 60 ? '👍 Bom' :
                         indicator.value >= 40 ? '⚠️ Atenção' : '🚨 Crítico'}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="border-0 shadow-sm bg-gradient-to-br from-green-50 to-green-100">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-green-200 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm text-green-700 font-medium">Pontos Fortes</p>
                      <p className="text-lg font-bold text-green-900">Controle de Gastos</p>
                    </div>
                  </div>
                  <p className="text-sm text-green-600">
                    Sua taxa de poupança está {summaryStats.savingsRate > 20 ? 'acima' : 'próxima da'} média recomendada.
                    Continue assim!
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm bg-gradient-to-br from-yellow-50 to-yellow-100">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-yellow-200 rounded-full flex items-center justify-center">
                      <AlertTriangle className="w-6 h-6 text-yellow-600" />
                    </div>
                    <div>
                      <p className="text-sm text-yellow-700 font-medium">Atenção</p>
                      <p className="text-lg font-bold text-yellow-900">
                        {expenseData.length > 0 ? expenseData[0].name : 'Despesas'}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm text-yellow-600">
                    {expenseData.length > 0 ? 
                      `Sua maior categoria de gasto (${expenseData[0].percentage}%). Considere otimizar.` :
                      'Monitore suas categorias de despesas regularmente.'
                    }
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm bg-gradient-to-br from-blue-50 to-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-blue-200 rounded-full flex items-center justify-center">
                      <Target className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm text-blue-700 font-medium">Oportunidade</p>
                      <p className="text-lg font-bold text-blue-900">Reserva de Emergência</p>
                    </div>
                  </div>
                  <p className="text-sm text-blue-600">
                    {summaryStats.netWorth > (summaryStats.totalExpenses * 6) ? 
                      'Sua reserva está adequada!' :
                      'Considere formar uma reserva de 6x suas despesas mensais.'
                    }
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Recommendations */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-600" />
                  Recomendações Personalizadas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {summaryStats.savingsRate < 10 && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <h4 className="font-medium text-red-800 mb-2">🚨 Taxa de Poupança Baixa</h4>
                      <p className="text-sm text-red-600">
                        Sua taxa de poupança está em {safeNumber(summaryStats.savingsRate).toFixed(1)}%. 
                        Tente reduzir gastos ou aumentar receitas para atingir pelo menos 20%.
                      </p>
                    </div>
                  )}
                  
                  {summaryStats.totalDebt > summaryStats.totalIncome * 0.5 && (
                    <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                      <h4 className="font-medium text-orange-800 mb-2">⚠️ Endividamento Alto</h4>
                      <p className="text-sm text-orange-600">
                        Suas dívidas representam mais de 50% da sua renda. 
                        Considere um plano de quitação acelerada.
                      </p>
                    </div>
                  )}
                  
                  {summaryStats.savingsRate > 20 && (
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="font-medium text-green-800 mb-2">✅ Parabéns!</h4>
                      <p className="text-sm text-green-600">
                        Sua disciplina financeira está excelente! 
                        Considere diversificar seus investimentos.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
