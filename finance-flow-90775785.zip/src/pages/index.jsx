import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Transactions from "./Transactions";

import Goals from "./Goals";

import BusinessDashboard from "./BusinessDashboard";

import Clients from "./Clients";

import Quotes from "./Quotes";

import Employees from "./Employees";

import BusinessTransactions from "./BusinessTransactions";

import Reports from "./Reports";

import Admin from "./Admin";

import AdminUsers from "./AdminUsers";

import AdminReports from "./AdminReports";

import AdminSettings from "./AdminSettings";

import WhatsappSetup from "./WhatsappSetup";

import CoupleDashboard from "./CoupleDashboard";

import CoupleTransactions from "./CoupleTransactions";

import CoupleGoals from "./CoupleGoals";

import CoupleReports from "./CoupleReports";

import CoupleSettings from "./CoupleSettings";

import Debts from "./Debts";

import Accounts from "./Accounts";

import CompanySettings from "./CompanySettings";

import BusinessReports from "./BusinessReports";

import Calendar from "./Calendar";

import BusinessCalendar from "./BusinessCalendar";

import CoupleCalendar from "./CoupleCalendar";

import AdminApiWebhooks from "./AdminApiWebhooks";

import SpendingLimits from "./SpendingLimits";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Transactions: Transactions,
    
    Goals: Goals,
    
    BusinessDashboard: BusinessDashboard,
    
    Clients: Clients,
    
    Quotes: Quotes,
    
    Employees: Employees,
    
    BusinessTransactions: BusinessTransactions,
    
    Reports: Reports,
    
    Admin: Admin,
    
    AdminUsers: AdminUsers,
    
    AdminReports: AdminReports,
    
    AdminSettings: AdminSettings,
    
    WhatsappSetup: WhatsappSetup,
    
    CoupleDashboard: CoupleDashboard,
    
    CoupleTransactions: CoupleTransactions,
    
    CoupleGoals: CoupleGoals,
    
    CoupleReports: CoupleReports,
    
    CoupleSettings: CoupleSettings,
    
    Debts: Debts,
    
    Accounts: Accounts,
    
    CompanySettings: CompanySettings,
    
    BusinessReports: BusinessReports,
    
    Calendar: Calendar,
    
    BusinessCalendar: BusinessCalendar,
    
    CoupleCalendar: CoupleCalendar,
    
    AdminApiWebhooks: AdminApiWebhooks,
    
    SpendingLimits: SpendingLimits,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Transactions" element={<Transactions />} />
                
                <Route path="/Goals" element={<Goals />} />
                
                <Route path="/BusinessDashboard" element={<BusinessDashboard />} />
                
                <Route path="/Clients" element={<Clients />} />
                
                <Route path="/Quotes" element={<Quotes />} />
                
                <Route path="/Employees" element={<Employees />} />
                
                <Route path="/BusinessTransactions" element={<BusinessTransactions />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/AdminUsers" element={<AdminUsers />} />
                
                <Route path="/AdminReports" element={<AdminReports />} />
                
                <Route path="/AdminSettings" element={<AdminSettings />} />
                
                <Route path="/WhatsappSetup" element={<WhatsappSetup />} />
                
                <Route path="/CoupleDashboard" element={<CoupleDashboard />} />
                
                <Route path="/CoupleTransactions" element={<CoupleTransactions />} />
                
                <Route path="/CoupleGoals" element={<CoupleGoals />} />
                
                <Route path="/CoupleReports" element={<CoupleReports />} />
                
                <Route path="/CoupleSettings" element={<CoupleSettings />} />
                
                <Route path="/Debts" element={<Debts />} />
                
                <Route path="/Accounts" element={<Accounts />} />
                
                <Route path="/CompanySettings" element={<CompanySettings />} />
                
                <Route path="/BusinessReports" element={<BusinessReports />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/BusinessCalendar" element={<BusinessCalendar />} />
                
                <Route path="/CoupleCalendar" element={<CoupleCalendar />} />
                
                <Route path="/AdminApiWebhooks" element={<AdminApiWebhooks />} />
                
                <Route path="/SpendingLimits" element={<SpendingLimits />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}