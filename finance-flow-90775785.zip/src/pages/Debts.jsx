import React, { useState, useEffect } from "react";
import { Debt } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Landmark, Calendar, Trash2, Edit } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import DebtForm from "../components/forms/DebtForm";

export default function DebtsPage() {
  const [debts, setDebts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingDebt, setEditingDebt] = useState(null);
  const [currentWorkspace, setCurrentWorkspace] = useState("personal");

  useEffect(() => {
    loadDebts();
  }, []);

  const loadDebts = async () => {
    setLoading(true);
    try {
      const user = await User.me();
      const workspace = user.current_workspace || "personal";
      setCurrentWorkspace(workspace);
      const data = await Debt.filter({ workspace: workspace });
      setDebts(data);
    } catch (error) {
      console.error("Erro ao carregar dívidas:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async (data) => {
    try {
      if (editingDebt) {
        await Debt.update(editingDebt.id, data);
      } else {
        await Debt.create(data);
      }
      setShowForm(false);
      setEditingDebt(null);
      loadDebts();
    } catch (error) {
      console.error("Erro ao salvar dívida:", error);
    }
  };

  const handleEdit = (debt) => {
    setEditingDebt(debt);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir esta dívida?")) {
      try {
        await Debt.delete(id);
        loadDebts();
      } catch (error) {
        console.error("Erro ao excluir dívida:", error);
      }
    }
  };

  const getProgress = (debt) => {
    if (!debt.total_amount) return 0;
    return Math.min((debt.paid_amount / debt.total_amount) * 100, 100);
  };

  return (
    <div className="flex-1 p-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-slate-900">Controle de Dívidas</h1>
          <Button onClick={() => { setEditingDebt(null); setShowForm(true); }} className="bg-blue-500 hover:bg-blue-600">
            <Plus className="w-4 h-4 mr-2" />
            Nova Dívida
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? <p>Carregando...</p> : debts.map(debt => (
            <Card key={debt.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <Landmark className="w-8 h-8 text-blue-500" />
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(debt)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(debt.id)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
                <CardTitle>{debt.title}</CardTitle>
                <p className="text-sm text-slate-600">Credor: {debt.creditor}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Progress value={getProgress(debt)} />
                  <div className="flex justify-between text-sm">
                    <span>Pago: R$ {debt.paid_amount.toFixed(2)}</span>
                    <span className="font-medium">Total: R$ {debt.total_amount.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center text-sm text-red-600 pt-2">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span>Vencimento todo dia {debt.due_day}</span>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg">R$ {debt.installment_amount.toFixed(2)}</p>
                    <p className="text-sm text-slate-500">por mês</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {showForm && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                <div className="w-full max-w-lg">
                    <DebtForm 
                        debt={editingDebt}
                        onSubmit={handleFormSubmit}
                        onCancel={() => { setShowForm(false); setEditingDebt(null); }}
                        workspace={currentWorkspace}
                    />
                </div>
            </div>
        )}
      </div>
    </div>
  );
}